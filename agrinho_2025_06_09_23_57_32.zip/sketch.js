function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let stringOffset = 0; // Keep for the guitar animation
let currentSlide = -1; // -1 for the initial start screen, 0 for first content slide
let slides = [];
let gameStarted = false; // Controls whether the main game/slideshow has started

// Game State Variables
let gameState = 'start'; // 'start', 'cutting', 'transport', 'slides'
let cutProgress = 0;
const MAX_CUT_PROGRESS = 100; // How many clicks/progress for cutting
let score = 0;
let treeX, treeY; // Position for the cutting tree

let truckX; // X position for the truck in transport phase
const TRUCK_SPEED = 2; // Speed of the truck

function setup() {
  createCanvas(440, 440);
  frameRate(60);
  setupSlides();
  textFont('Georgia');

  treeX = width / 2;
  treeY = height / 2 + 50;

  truckX = -100; // Start truck off-screen
}

function draw() {
  background(80, 150, 255); // fundo azul

  switch (gameState) {
    case 'start':
      drawStartScreen();
      break;
    case 'cutting':
      drawCuttingGame();
      break;
    case 'transport':
      drawTransportGame();
      break;
    case 'slides':
      drawSlideText();
      drawIllustration(currentSlide);
      drawButtons(); // Draw navigation buttons for slides
      break;
  }

  // Always draw score if game has started
  if (gameStarted) {
    drawScore();
  }
}

function drawScore() {
  fill(255, 255, 0); // Yellow color for score
  textSize(16);
  textAlign(LEFT, TOP);
  text("Pontos: " + score, 10, 10);
}

function drawStartScreen() {
  // Agrinho 2025 text
  let glow = map(sin(frameCount * 0.05), -1, 1, 150, 255);
  fill(255, glow);
  textAlign(CENTER, CENTER);
  textSize(30);
  text("Agrinho 2025", width / 2, height / 2 - 50);

  // Iniciar button
  let buttonWidth = 120;
  let buttonHeight = 40;
  let buttonX = width / 2 - buttonWidth / 2;
  let buttonY = height / 2 + 20;

  stroke(0, 50);
  strokeWeight(1);
  fill(240);
  rect(buttonX, buttonY, buttonWidth, buttonHeight, 8);
  fill(0);
  noStroke();
  textSize(18);
  text("Iniciar", buttonX + 40, buttonY + 20); // Center text in button
}

// --- Game Phases ---

function drawCuttingGame() {
  textAlign(CENTER, CENTER);
  textSize(24);
  fill(255);
  text("Corte a Árvore!", width / 2, 40);

  // Draw the tree
  push();
  translate(treeX, treeY);
  noStroke();
  fill(130, 90, 60); // Trunk
  rect(-15, 0, 30, 100);
  fill(90, 120, 90); // Leaves
  ellipse(0, -40, 120, 120);
  ellipse(-40, -20, 90, 90);
  ellipse(40, -20, 90, 90);
  pop();

  // Draw progress bar
  let barWidth = 200;
  let barHeight = 20;
  let currentBarWidth = map(cutProgress, 0, MAX_CUT_PROGRESS, 0, barWidth);
  fill(150);
  rect(width / 2 - barWidth / 2, height - 70, barWidth, barHeight);
  fill(50, 200, 50); // Green progress
  rect(width / 2 - barWidth / 2, height - 70, currentBarWidth, barHeight);

  fill(255);
  textSize(16);
  text("Progresso: " + floor(map(cutProgress, 0, MAX_CUT_PROGRESS, 0, 100)) + "%", width / 2, height - 40);
}

function drawTransportGame() {
  textAlign(CENTER, CENTER);
  textSize(24);
  fill(255);
  text("Transporte a Madeira!", width / 2, 40);

  // Draw the road
  fill(100);
  rect(0, height / 2 + 50, width, 50);
  for (let i = 0; i < width; i += 40) {
    fill(255, 255, 0);
    rect(i, height / 2 + 70, 20, 5);
  }

  // Draw the truck (simplified, with "wood" on it)
  push();
  translate(truckX, height / 2 + 60);
  fill(160); // Truck body
  rect(0, 0, 100, 40, 5);
  fill(100); // Cabin
  rect(100, 5, 40, 30, 5);
  fill(60); // Wheels
  ellipse(20, 40, 20);
  ellipse(120, 40, 20);

  // Draw wood on truck
  fill(130, 90, 60);
  rect(20, -20, 60, 20);
  pop();

  // Move the truck
  let speed = TRUCK_SPEED;
if (keyIsDown(87)) { // W
  speed += 2;
}
if (keyIsDown(68)) { // D
  truckX += speed;
}
if (keyIsDown(65)) { // A
  truckX -= speed;
}


  // Check if truck reached destination
  if (truckX > width + 50) { // Off-screen to the right
    score += 100; // Bonus for transport
    gameState = 'slides'; // Transition to slides
    currentSlide = 0; // Start slides from the beginning
    truckX = -100; // Reset truck position for next potential play
  }
}

// --- Original Slide Functions (adapted) ---

function setupSlides() {
  slides = [
    [
      "Do campo vem a madeira,",
      "nascida em florestas cultivadas.",
      "É lá que tudo começa."
    ],
    [
      "O corte da árvore é feito com cuidado,",
      "respeitando o tempo da natureza,",
      "e gerando renda para famílias rurais."
    ],
    [
      "A madeira segue para a cidade,",
      "transportada por estradas que",
      "ligam o interior aos centros urbanos."
    ],
    [
      "Na fábrica da cidade,",
      "a madeira se transforma em arte:",
      "nasce o violão, fruto da união."
    ],
    [
      "Campo e cidade se conectam,",
      "como cordas vibrando em harmonia,",
      "trazendo música, cultura e história."
    ]
  ];
}

function drawSlideText() {
  let glow = map(sin(frameCount * 0.05), -1, 1, 150, 255);
  fill(255, glow);
  textAlign(CENTER, CENTER);
  textSize(20);

  let lines = slides[currentSlide];
  for (let i = 0; i < lines.length; i++) {
    text(lines[i], width / 2, 40 + i * 30);
  }
}

function drawIllustration(slide) {
  push();
  translate(width / 2, 240);
  noStroke();
  fill(200);

  if (slide === 0 || slide === 1) {
    // Árvore realista (smaller version for slide)
    fill(130, 90, 60);
    rect(-10, 60, 20, 70);
    fill(90, 120, 90);
    ellipse(0, 20, 100, 100);
    ellipse(-30, 40, 80, 80);
    ellipse(30, 40, 80, 80);
  } else if (slide === 2) {
    // Caminhão (smaller version for slide)
    fill(160);
    rect(-70, 60, 100, 40, 5);
    fill(100);
    rect(30, 65, 40, 30, 5);
    fill(60);
    ellipse(-50, 100, 20);
    ellipse(50, 100, 20);
  } else if (slide === 3) {
    // Fábrica (smaller version for slide)
    fill(180);
    rect(-60, 40, 120, 60);
    fill(120);
    rect(-30, -20, 20, 60);
    fill(100);
    for (let i = -40; i <= 40; i += 20) {
      rect(i, 60, 15, 20);
    }
  } else if (slide === 4) {
    // Violão (using the original drawGuitar and animateStrings)
    pop(); // Pop the current translation/rotation before calling drawGuitar
    drawGuitar(width / 2, 240); // Call original drawGuitar
    animateStrings(width / 2, 240); // Call original animateStrings
    push(); // Push back for consistency if more drawing follows
    translate(width / 2, 240);
  }

  pop();
}

function drawGuitar(x, y) {
  push();
  translate(x, y);
  rotate(-PI / 8);

  noStroke();

  fill(181, 101, 29);
  ellipse(0, 40, 100, 130);

  ellipse(0, -30, 70, 90);

  fill(30);
  ellipse(0, 10, 20, 20);

  fill(100, 60, 20);
  rect(-10, -120, 20, 80);

  fill(70, 40, 10);
  rect(-12, -140, 24, 20);

  fill(220);
  ellipse(-10, -140, 5, 5);
  ellipse(10, -140, 5, 5);
  ellipse(-10, -132, 5, 5);
  ellipse(10, -132, 5, 5);

  pop();
}

function animateStrings(x, y) {
  push();
  translate(x, y);
  rotate(-PI / 8);

  stroke(255);
  strokeWeight(1);
  for (let i = -3; i <= 3; i++) {
    let offset = sin(frameCount * 0.2 + i) * 1.5;
    line(i * 2, -140, i * 2 + offset, 90);
  }

  pop();
}

function drawButtons() {
  // Only draw "Avançar" if not on the last slide
  if (currentSlide < slides.length - 1) {
    drawNextButton();
  }

  // Only draw "Voltar" if not on the first content slide
  if (currentSlide > 0) {
    drawPrevButton();
  }
}

function drawNextButton() {
  let x = width - 100;
  let y = height - 50;
  stroke(0, 50);
  strokeWeight(1);
  fill(240);
  rect(x, y, 80, 30, 8);
  fill(0);
  noStroke();
  textAlign(CENTER, CENTER);
  textSize(14);
  text("Avançar", x + 40, y + 15);
}

function drawPrevButton() {
  let x = 20;
  let y = height - 50;
  stroke(0, 50);
  strokeWeight(1);
  fill(240);
  rect(x, y, 80, 30, 8);
  fill(0);
  noStroke();
  textAlign(CENTER, CENTER);
  textSize(14);
  text("Voltar", x + 40, y + 15);
}

function mousePressed() {
  if (gameState === 'start') {
    // Check if "Iniciar" button is clicked
    let buttonWidth = 120;
    let buttonHeight = 40;
    let buttonX = width / 2 - buttonWidth / 2;
    let buttonY = height / 2 + 20;
    if (mouseX > buttonX && mouseX < buttonX + buttonWidth && mouseY > buttonY && mouseY < buttonY + buttonHeight) {
      gameStarted = true;
      score = 0; // Reset score for new game
      gameState = 'cutting'; // Start the cutting game
    }
  } else if (gameState === 'cutting') {
    // Check if mouse is over the tree for cutting
    let treeRadiusX = 60; // Approximate half width of tree
    let treeRadiusY = 60; // Approximate half height of tree
    if (dist(mouseX, mouseY, treeX, treeY - 40) < treeRadiusY) { // Check distance to tree top
      cutProgress += 5; // Increase progress on click
      score += 10; // Award points for cutting
      if (cutProgress >= MAX_CUT_PROGRESS) {
        score += 50; // Bonus for finishing cut
        gameState = 'transport'; // Move to transport phase
        cutProgress = 0; // Reset for next time
      }
    }
  } else if (gameState === 'slides') {
    // Advance
    let nextX = width - 100;
    let nextY = height - 50;
    if (mouseX > nextX && mouseX < nextX + 80 && mouseY > nextY && mouseY < nextY + 30) {
      if (currentSlide < slides.length - 1) {
        currentSlide++;
      }
    }
    // Go back
    let prevX = 20;
    let prevY = height - 50;
    if (mouseX > prevX && mouseX < prevX + 80 && mouseY > prevY && mouseY < prevY + 30) {
      if (currentSlide > 0) {
        currentSlide--;
      }
    }
  }
}